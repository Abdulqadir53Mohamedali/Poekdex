const btnSearch = document.getElementById("btnSearch");

btnSearch.addEventListener("click", () =>{

    let pokemonName = document.getElementById("search").value;

    let url  = `https://pokeapi.co/api/v2/pokemon/${pokemonName.toLowerCase()}`;


    // console.log writes to console 
    // write.log writes to html

    fetch(url)
    .then(res => res.json())
    .then(res =>{
        console.log(res);
        const mainImage = document.querySelector(".main-image");
        mainImage.innerHTML = `<img src="${res.sprites.front_default}">`;

        const name = document.querySelector("#name")
        name.textContent = res.name.toUpperCase();
        name.style.fontSize = "20px";

        const height = document.querySelector("#height");
        height.innerHTML = `Height: ${res.height}m <br>`;
        
        const weight = document.querySelector("#weight");
        weight.innerHTML = `Weight: ${res.weight}kg`;
        
        const types = document.querySelector("#types");
        const ability = document.querySelector("#ability");
        types.innerHTML = "";

        for (let index = 0; index < res.types.length; index++) {
            types.innerHTML += `<span class ="${res.types[index].type.name}">${res.types[index].type.name.toUpperCase()}</span>  `; 
            
        }
        
        const stats = document.querySelector("#stats");
        stats.innerHTML = "<b>Stats:<b><br>";

        for (let index = 0; index < res.stats.length; index++) {

            let name = res.stats[index].stat.name.toUpperCase();
            let percentage = (res.stats[index].base_stat / 450) * 100
            
            stats.innerHTML += `<div>${name}</div>
          <div class="progress" role="progressbar" aria-label="Example 20px high" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="height: 20px">
            <div class="progress-bar" style="width: ${percentage}%">${res.stats[index].base_stat}</div>
          </div>` 
        }



        ability.innerHTML = "<b>Abilities:<b><br>";
        
        for (let index = 0; index < res.abilities.length; index++) {
          let abilityName = res.abilities[index].ability.name.toUpperCase();
          ability.innerHTML += `<span>${abilityName}</span><br> `;
        }



        function movesModal(numberOfMoves, data, pokemon) {

          // Modal variables

          if (numberOfMoves <= 10) {

            const moves = document.querySelector(".moves");

            moves.innerHTML = `<strong>Moves: </strong>`;

            // prints all the moves

            for (let index = 0; index < data.moves.length; index++) {

              moves.innerHTML += `<div class="move-list ${data.moves[index].move.name}">${filterText(data.moves[index].move.name)}</div>`;

            }

          } else {

            const moves = document.querySelector(".moves");

            moves.innerHTML = `<strong>Moves: </strong>`;

            // Prints 10 moves and a button

            for (let index = 0; index < 10; index++) {

              moves.innerHTML += `<div class="move-list">${filterText(data.moves[index].move.name)}</div>`;

            }

            moves.innerHTML += `<button type="button" class="more-btn" data-bs-toggle="modal" data-bs-target="#movesPopup">

            View all moves

          </button>`;

            const modalTitle = document.querySelector("#moves-title");

            const modalBody = document.querySelector("#moves-body");

        

            // Modal content

            modalTitle.innerHTML = `${filterText(pokemon)}'s Moves`;

            for (let index = 0; index < data.moves.length; index++) {

              modalBody.innerHTML += `<div class="move-list ${data.moves[index].move.name}">${filterText(data.moves[index].move.name)}</div>`;

            }

          }

        }
        movesModal(data.moves.length, data, pokemon);



        
    })

})
